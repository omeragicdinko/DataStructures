package Queue;

public class Node<Item> {
	Item data;
	Node<Item> next;
}
