package DoublyLinkedList;

public class Node<Item> {
	Item data;
	Node<Item> next;
	Node<Item> previous;
}
